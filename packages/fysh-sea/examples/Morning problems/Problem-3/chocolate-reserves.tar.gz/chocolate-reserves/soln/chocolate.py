line = input().split()
chocolates = int(line[0])
jars = int(line[1])
count = 0

# write your code here

print(count)
